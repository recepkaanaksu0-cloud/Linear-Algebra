Defn: (Row Reduced Form of a Matrix)
A matrix $C$ is said to be in the row reduced form if 
(1) the first non-zero entry in each row of $C$ is 1.
(2) The column containing this 1 has all its other entries zero.

A matrix in the row reduced form is also called a row reduced matrix.

Ex: (1) One of the most important examples of a row reduced matrix is the $n\times n$ identity matrix In.
$$\begin{bmatrix}
1 & 0 & \dots & 0 \\
0 & 1 & \dots & \vdots\\
\vdots & \vdots & 1 & \vdots\\
0 & \dots & \dots & 1
\end{bmatrix}$$
(2) The matrices
$$\begin{bmatrix}
0 & 1 & 0 & -1 \\
0 & 0 & 0 & 0\\
0 & 0 & 1 & 0
\end{bmatrix}$$
is a row reduced matrix
$$\begin{bmatrix}
0 & 1 & 0 & 4 & 0 \\
0 & 0 & 0 & 0 & 1\\
0 & 0 & 1 & 1 & 0 \\
0 & 0 & 0 & 0 & 0
\end{bmatrix}$$
is a row reduced matrix

(3) The matrix
$$\begin{bmatrix}
1 & 0 & 0 & 0 & 5 \\
0 & 1 & 1 & 1 & 2\\
0 & 0 & 0 & 1 & 1 \\
0 & 0 & 0 & 0 & 0
\end{bmatrix}$$
is not a row reduced matrix

(4) The matrix
$$\begin{bmatrix}
1 & 0 & 0 & 3 \\
0 & 0 & 2 & 1 \\
0 & 0 & 1 & 0 \\
\end{bmatrix}$$
is not a row reduced matrix.

Defn: (Leading Term, Leading Column)
For a row-reduced matrix the first non-zero entry of any row is called a leading term. The columns containing the leading terms are called the leading columns.

Remark: Its is very important to observe that if there are r non-zero rows in the row reduced form of the matrix, then there will be r leading terms That is , there will be r leading columns. 