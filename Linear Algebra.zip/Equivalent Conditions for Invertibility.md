Defn: A square matrix $A$ of order $n$ is said to be of full rank if $rank(A)=n$.

Theorem: For a square matrix $A$ of order $n$, t.f.s.a.e:
(1) $A$ is invertible.
(2) $A$ is of full rank.
(3) $A$ is row equivalent to the identity matrix.
(4) $A$ is product of elementary matrices.

Theorem: The following statemenets are equivalent for a square matrix $A$ of order $n$.
(1) $A$ is invertible.
(2) $Ax=0$ has only the trivial solution $X=0$.
(3) $Ax=b$ has a solution $X$ for every $b$.