Defn: (Row rank of a Matrix)
The number of non-zero rows in the row reduced form of a matrix is called the row-rank of the matrix.

Ex: Determine the row-rank of
$A=\begin{bmatrix} 1 & 2 & 1\\ 2 & 3 & 1\\ 1 & 1 & 2\end{bmatrix}$
Solution:
$R_{21}(-2)R_{31}(-1)=>\begin{bmatrix} 1 & 2 & 1\\ 0 & -1 & -1\\ 0 & -1 & 1\end{bmatrix}$

$R_2(-1)=>\begin{bmatrix} 1 & 2 & 1\\ 0 & 1 & 1\\ 0 & -1 & 1\end{bmatrix}$

$R_{32}(1)=>\begin{bmatrix} 1 & 2 & 1\\ 0 & 1 & -1\\ 0 & 0 & 2\end{bmatrix}$

$R_3(1/2)=>\begin{bmatrix} 1 & 2 & 1\\ 0 & 1 & 1\\ 0 & 0 & 1\end{bmatrix}$

$R_{12}(-2)=>\begin{bmatrix} 1 & 0 & -1\\ 0 & 1 & 1\\ 0 & 0 & 1\end{bmatrix}$

$R_{13}(1)R_{23}(-1)=>\begin{bmatrix} 1 & 0 & 0\\ 0 & 1 & 0\\ 0 & 0 & 1\end{bmatrix}$
The row-rank of $A$ is 3.