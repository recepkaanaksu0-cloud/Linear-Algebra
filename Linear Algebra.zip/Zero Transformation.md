Defn: (Zero Transformation)
let $V$ be a vector space and let $T:\space V\rightarrow W$ be the map defined by $T(v)=O_W$ for every $v\in V$. Then $T$ is a linear transformation such a linear transformation is called the zero transformation an d denoted by $0$.

Defn: (Identity Trnsformation)
let $V$ be a vector space and let $T:\space V\rightarrow V$ be the map defined by $T(v)=v$ for every $v\in V$. Then $T$ is a linear transformation. Such a linear transformation is called the identity transformation and denoted by $I$.

Theorem: let $T:\space V\rightarrow W$ be linear transformation and $B=(u_1,u_2,\dots,u_n)$ be an ordered basis of $V$. Then the linear transformation $T$ is a linear combination of the vectors $T(u_1),T(u_2),\dots,T(u_n)$. In other words $T$ is determined by $T(u_1),\dots,T(u_n)$.

Theorem: let $T:\space V\rightarrow W$ be a linear transformation. For $w\in W$ define the set $T^{-1}(w)=\{v\in V|T(v)=w\}$. Suppose that the map $T$ is one-to-one and onto.

(1) Then for each $w\in W$, the set $T^{-1}(w)$ is the set consisting of a single element.
(2) The map $T^{-1}:\space W\rightarrow V$ defined by $T^{-1}(w)=v$ whenever $T(v)=w$ is a linear transformation.

Ex:
$T:\space\mathbb{R}^2\rightarrow\mathbb{R}^2$
$(x,y)\rightarrow(x,y)$
$T^{-1}((2,2))=\{(x,y)\in\mathbb{R}^2|T((x,y))=(2,2)\}$
$=\{(x,y)\in\mathbb{R}^2|(x,y)=(2,2)\}$
$=\{(2,2)\}$

Ex:
$T:\space\mathbb{R}\rightarrow\mathbb{R}^2$
$x\rightarrow(x,3x)$
$T^{-1}((3,5))=\{x\in\mathbb{R}|T(x)=(3,5)\}$
$=\{x\in\mathbb{R}|(x,3x)=(3,5)\}=\emptyset$
