Defn: Gaussian elimination is a method of solving a linear system $Ax=b$ (consisting $m$ equations in $n$ unknowns) by bringing the augmented matrix 
$$
\begin{bmatrix}
a_{11} & \dots & a_{1n} :& b_1\\
\vdots & \vdots & \vdots & \vdots\\
a_{m1} & \dots & a_{mn} :& b_m
\end{bmatrix}
$$
to an upper triangular form
$$
\begin{bmatrix}
c_{11} & c_{12} & ... & c_{1n} :& d_1\\
0 & c_{22} & ... & ... :& \vdots \\
\vdots & \vdots & \ddots & ... :& \vdots \\
0 & ... & ... & c_{mn} :& d_m
\end{bmatrix}
$$
This elimination process is also called forward elimination method.
Ex: Solve the lineer system by using Gauss elimination method.

$0x+y+z=2$
$2x+3z=5$
$x+y+z=3$

$\begin{bmatrix}0 & 1 & 1 :& 2\\2 & 0 & 3 :& 5\\1 & 1 & 1 :& 3\end{bmatrix}$

$R_{13}$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\2 & 0 & 3 :& 5\\0 & 1 & 1 :& 2\end{bmatrix}$

$R_{21}(-2)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & -2 & 3 :& -1\\0 & 1 & 1 :& 2\end{bmatrix}$

$R_{23}(3)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 4 :& 5\\0 & 1 & 1 :& 2\end{bmatrix}$

$R_{32}(-1)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 4 :& 5\\0 & 0 & -3 :& -3\end{bmatrix}$

$R_3(-1/3)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 4 :& 5\\0 & 0 & 1 :& 1\end{bmatrix}$

$R_{23}(-4)$ =>$
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 0 :& 1\\0 & 0 & 1 :& 1\end{bmatrix}$

$R_12(-1)$ =>
$\begin{bmatrix}1 & 0 & 1 :& 2\\0 & 1 & 0 :& 1\\0 & 0 & 1 :& 1\end{bmatrix}$

$R_{13}(-1)$ =>
$\begin{bmatrix}1 & 0 & 0 :& 1\\0 & 1 & 0 :& 1\\0 & 0 & 1 :& 1\end{bmatrix}$

The set of solution is $(x, y, z)=(1, 1, 1)$.

Ex: Solve the linear system by using Gauss elimination method.

$x+y+z=3$
$x+2y+2z=5$
$3x+4y+4z=11$

$\begin{bmatrix}1 & 1 & 1 :& 3\\1 & 2 & 2 :& 5\\3 & 4 & 4 :& 11\end{bmatrix}$

$R_{21}(-1)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 1 :& 2\\3 & 4 & 4 :& 11\end{bmatrix}$

$R_{31}(-3)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 1 :& 2\\0 & 1 & 1 :& 2\end{bmatrix}$

$R_{32}(-1)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 1 :& 2\\0 & 0 & 0 :& 0\end{bmatrix}$

The set of solution is $(x, y, z) = (1, 2-z, z)$ with arbitrary z.

Ex: Solve the linear system by using Gauss elimination method.

$x+y+z=3$
$x+2y+2z=5$
$3x+4y+4z=12$

$\begin{bmatrix}1 & 1 & 1 :& 3\\1 & 2 & 2 :& 5\\3 & 4 & 4 :& 12\end{bmatrix}$

$R_{21}(-1)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 1 :& 2\\3 & 4 & 4 :& 12\end{bmatrix}$

$R_{31}(-3)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 1 :& 2\\0 & 1 & 1 :& 3\end{bmatrix}$

$R_{32}(-1)$ =>
$\begin{bmatrix}1 & 1 & 1 :& 3\\0 & 1 & 1 :& 2\\0 & 0 & 0 :& 0\end{bmatrix}$
