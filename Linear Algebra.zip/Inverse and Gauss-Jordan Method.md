let $A$ be an $n\times n$ matrix. Apply the Gauss Jordan Method to the matrix $[A\space In]$.
Suppose the row reduced echelon form of the matrix $[A\space In]$ is $[B C]$. If $B=In$, then $A^{-1}=C$ or else $A$ is not invertible.

Ex: Find the inverse of the matrix $A=\begin{bmatrix} 2 & 1 & 1\\ 1 & 2 & 1\\ 1 & 1 & 2\end{bmatrix}$ using Gauss-Jordan method.
Solution:

$R_1(1/2)=>R_{21}(-1)=>R_{31}(-1)=>R_2(2/3)=>R_{12}(-1/2)=>R_{32}(-1/2)=>R_3(3/4)=>R_{13}(-1/3)=>R_{23}(-1/3)$

Ödev: Find the inverse (if exists) of the following matrices using Gauss-Jordan Method.

$A=\begin{bmatrix} 1 & 2 & 3\\ 1 & 3 & 2\\ 2 & 4 & 7\end{bmatrix}$

$B=\begin{bmatrix} 1 & 3 & 3\\ 2 & 3 & 2\\ 2 & 4 & 7\end{bmatrix}$

Solution of $A$:
$A=\begin{bmatrix} 1 & 2 & 3\\ 1 & 3 & 2\\ 2 & 4 & 7\end{bmatrix}\begin{bmatrix} 1 & 0 & 0\\ 0 & 1 & 0\\ 0 & 0 & 1\end{bmatrix}$

$R_{21}(-1)R_{31}(-2)=>$
$\begin{bmatrix} 1 & 2 & 3\\ 0 & 1 & -1\\ 0 & 0 & 1\end{bmatrix}\begin{bmatrix} 1 & 0 & 0\\ -1 & 1 & 0\\ -2 & 0 & 1\end{bmatrix}$

$R_{12}(-2)=>$
$\begin{bmatrix} 1 & 0 & 5\\ 0 & 1 & -1\\ 0 & 0 & 1\end{bmatrix}\begin{bmatrix} 3 & -2 & 0\\ -1 & 1 & 0\\ -2 & 0 & 1\end{bmatrix}$

$R_{23}(1)R_{13}(-5)=>$
$\begin{bmatrix} 1 & 0 & 0\\ 0 & 1 & 0\\ 0 & 0 & 1\end{bmatrix}\begin{bmatrix} 13 & -2 & -5\\ -3 & 1 & 1\\ -2 & 0 & 1\end{bmatrix}$

$A^-=\begin{bmatrix} 13 & -2 & -5\\ -3 & 1 & 1\\ -2 & 0 & 1\end{bmatrix}$

Solution of $B$:
$B=\begin{bmatrix} 1 & 3 & 3\\ 2 & 3 & 2\\ 2 & 4 & 7\end{bmatrix}\begin{bmatrix} 1 & 0 & 0\\ 0 & 1 & 0\\ 0 & 0 & 1\end{bmatrix}$

$R_{21}(-2)R_{31}(-2)=>$
$\begin{bmatrix} 1 & 3 & 3\\ 0 & -3 & -4\\ 0 & -2 & 1\end{bmatrix}\begin{bmatrix} 1 & 0 & 0\\ -2 & 1 & 0\\ -2 & 0 & 1\end{bmatrix}$

$R_2(-1/3)=>$
$\begin{bmatrix} 1 & 3 & 3\\ 0 & 1 & 4/3\\ 0 & -2 & 1\end{bmatrix}\begin{bmatrix} 1 & 0 & 0\\ 2/3 & -1/3 & 0\\ -2 & 0 & 1\end{bmatrix}$

$R_{12}(-3)R_{32}(2)=>$
$\begin{bmatrix} 1 & 0 & -1\\ 0 & 1 & 4/3\\ 0 & 0 & 11/3\end{bmatrix}\begin{bmatrix} -1 & 1 & 0\\ 2/3 & -1/3 & 0\\ -2/3 & -2/3 & 1\end{bmatrix}$

$R_3(3/11)=>$
$\begin{bmatrix} 1 & 0 & -1\\ 0 & 1 & 4/3\\ 0 & 0 & 1\end{bmatrix}\begin{bmatrix} -1 & 1 & 0\\ 2/3 & -1/3 & 0\\ -2/11 & -2/11 & 3/11\end{bmatrix}$

$R_{13}(1)R_{23}(-4/3)=>$
$\begin{bmatrix} 1 & 0 & 0\\ 0 & 1 & 0\\ 0 & 0 & 1\end{bmatrix}\begin{bmatrix} -13/11 & 9/11 & 3/11\\ 10/11 & -5/11 & -4/11\\ -2/11 & -2/11 & 3/11\end{bmatrix}$

$B^-=\begin{bmatrix} -13/11 & 9/11 & 3/11\\ 10/11 & -5/11 & -4/11\\ -2/11 & -2/11 & 3/11\end{bmatrix}$
