Defn: A matrix obtained by deleting some of rows and/or columns of a matrix is said to be a submatrix of the given matrix.

Defn: For a square matrix $A$ of order $n$ we define trace of $A$ denoted by $tr(A)$ as $tr(A)=a_{11}+a_{22}+...a_{nn}$

Theorem: let $A,B$ be a square matrices of order $n$. Then the following conditions are hold:
(a) $tr(A+B)=tr(A)+tr(B)$
(b) $tr(AB)=tr(BA)$
$$
\begin{bmatrix}
1 & 2 & 3 \\
4 & 5 & 6 \\
7 & 8 & 9
\end{bmatrix}
$$
Matrices Over Complex Numbers
(1) let $A$ be an $m\times n$ matrix over ℂ.
If $A[a_{ij}]$, then the conjugate of A denoted by À is thematrix $B=[bij]$ with $b_{ij}=à_{ij}$ ($À=[à_{ij}]$)
(2) let A be an $m\times n$ matrix over ℂ.
If $A=[a_{ij}]$, then conjugate transpose of A denoted by $A^*$ is the matrix $B=[b_{ij}]$ with $b_{ij}=à_{ij}$

Ex: 
let $A=\begin{bmatrix}2+3i & 1 \\0 & 5-7i\end{bmatrix}$

$A^t=\begin{bmatrix}2+3i & 0 \\1 & 5-7i\end{bmatrix}$

$A^*=\begin{bmatrix}2-3i & 0 \\1 & 5+7i\end{bmatrix}$

(3) A square matrix $A$ over ℂ is called Hermition if $A^*=A$
(4) A square matrix $A$ over ℂ is called skew-Hermition if $A^*=-A$
(5) A square matrix $A$ over ℂ is called unitary if $AA^*=I=A^*A^*$
(6) A square matrix $A$ over ℂ is called normal if $AA^*=A^*A^*$

$A^*=A$ (ℂ) Hermition
$A^t=A$ (R) symmetric

Linear System of Equations
Defn: A linear System of m equations in $n$ unknowns $x_1, x_2, ..., x_n$ is a set of equations of the form
$a_{11}x_1+a_{12}x_2+...+a_{1n}x_n=b_1$
$a_{21}x_1+a_{22}x_2+...+a_{2n}x_n=b_2$
$a_{n1}x_1+a_{n2}x_2+...+a_{nn}x_n=b_n$

where $1_<i_<m$ and $1_<j_<n$ $a_{ij}$, bi ∈ R. Linear system $*$ is called homegeneous if $b_1=b_2=...=b_n=0$, non-homegeneous otherwise.
we write the above equations in the form $Ax=b$ where

$A=\begin{bmatrix}a_{11} & a_{12} & ... & a_{1n} \\a_{m1} & a_{m2} & ... & a_{mn}\end{bmatrix}$

$X=\begin{bmatrix}x_1 \\x_2 \\... \\x_n\end{bmatrix}$

$B=\begin{bmatrix}b_1 \\b_2 \\... \\b_n\end{bmatrix}$
$Ax=\begin{bmatrix}a_{11}x_1+a_{12}x_2+...+a_{1n}x_n \\...\end{bmatrix}=\begin{bmatrix}b_1 \\b_2 \\ \vdots \\b_n\end{bmatrix}$
The matrix A is called the coefficent  matrix and the matrix $[A b]$ is the augmented matrix of the linear system.
$[A b]=\begin{bmatrix}a_{11} & \dots & a_{1n} & b_1  \\ \vdots & \ddots & \dots & \vdots \\ \vdots & \vdots & \ddots & \vdots \\a_{m1} & ... & a_{mn} & b_m\end{bmatrix}$
for a system of linear equations Ax=b the system Ax=0 is called the associated homogeneous system.
Defn: (Solution of a Linear System)
A solution of the linear system Ax=b is a column vector y with entries y1,y2,y3,...yn such that the linear system  *** is satisfied by substituing yi in place of X :
$Y=\begin{bmatrix}y_1 \\y_2 \\... \\y_n\end{bmatrix}$
Note: The zero n-type $X=0$ is always a solution of the system $Ax=0$ and it is called the trivial solution.

$\begin{bmatrix}0 \\0 \\ \vdots \\0\end{bmatrix}= \begin{bmatrix}0 \\0 \\ \vdots \\0\end{bmatrix}$

A non-zero n-tuple $X$. if it satisfies $Ax=0$ is called a non-trivial solution. 
A Solution Method
Ex: let us solve the linear system
$x+7y+3z=11$
$x+y+z=3$
$4x+10y-z=13$
Ans:
$x=y=z=1$

Row Operations and Equivalent Systems
Defn: (Elementary Operations)
The following operations are called elementary operations
(1) Interchange of two equations

(2) Multiply a non-zero constant throughout an equation. 
say multiply the $k^{th}$ equation by $c\neq0$.

(3) Replace an equation by itself plus a constant multiple of another equation
say replace the $k^{th}$ equation by $k^{th}$ equation plus $c \times j^{th}$ equations

Defn: (Equivalent Linear Systems)
Two linear systems are said to be equivalent if one can be obtained from the other by a finite number of elementary operations.

Lemma: let $cx=d$ be the linear system obtained from the linear system Ax=b by asingle elementary operation.
Then the linear systems $Δx=b$ and $cx=d$ have the same set of solution.

Theorem: Two equvalent systems have the same set of solutions.
Note: In place of looking at the system of equations as a whole, we just need to work with coefficients.
These coefficients when arranged in a rectangular array gives us augmented matrix $[A b]$.

Defn: (Elementary Row Operations)
