Definition: A rectangular array of numbers is called a matrix. We shall mostly be concerned with matrices having real numbers.

The horizontal arrays of matrix are called its rows and the vertical arrays of matrix are called collums.
