Defn: (Linear Independence and Dependence)
let $S=$ $\{u_1,\dots,u_m\}$ be only non-empty subset of $V$. If there exist some non-zero $\alpha_i$'s $1≤i≤m$ such that $\alpha_1 u_1+\dots+\alpha_m u_m=0$.

Ex:
(1) let $S=$ $\{(1,2,1),(2,1,4),(3,3,5)\}$. Is $S$ a linearly dependent subset of $\mathbb{R}^3$?
$\alpha_1(1,2,1)+\alpha_2(2,1,4)+\alpha_3(3,3,5)=(0,0,0)$
$\alpha_1+2\alpha_2+3\alpha_3=0$
$2\alpha_1+\alpha_2+3\alpha_3=0$
$\alpha_1+4\alpha_2+5\alpha_3=0$
$\alpha_1=1,\alpha_2=1,\alpha_3=-1$
$(3,3,5)=(1,2,1)+(2,1,4)$

(2) let $S=$ $\{(1,1,1),(1,1,0),(1,0,1)\}$
Is $S$ a linearly dependent subset of $\mathbb{R}^3$?
$a(1,1,1)+b(1,1,0)+c(1,0,1)=(0,0,0)$
$a+b+c=0$
$a+b=0$
$a+c=0$
$c=0,b=0,a=0$
