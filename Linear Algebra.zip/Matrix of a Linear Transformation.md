Defn: let $L:V\rightarrow W$ be a linear transformation and consider the ordered basis $S=\{v_1,v_2,\dots,v_n\}$ and $T=\{w_1,w_2,\dots,w_n\}$ for the vector spaces $V$ and $W$, respectively.
The linear matris of the linear transformation $L$ with respect to the basis $S$ and $T$ is defined by $A=[[L(v_1)]_T\space[L(v_2)]_T\space\dots\space[L(v_n)]]_{m\times n}$
Theorem: let $L:\mathbb{R}^n\rightarrow\mathbb{R}^m$ be a linear transformation and consider standard bases $\{e_1,e_2,\dots,e_n\}$ for $\mathbb{R}^n$ let $A=[L(e_1)\space L(e_2)\space\dots\space L(e_n)]_{m\times n}$. The matrix $A$ is the only matrix satisfying the property: $L(x)=AX$ for $x\in\mathbb{R}^n$. It is called the standart matrix representation of the linear transformation $L$.

Remark: Linear transformation $L\leftrightarrow A$.
If $A$ is $m\times n$ matrix then there is a corresponding linear transformation $L:\mathbb{R}^n\rightarrow\mathbb{R}^m$ s.t $L(x)=AX$ for $x\in\mathbb{R}^n$.
If $L:\mathbb{R}^n\rightarrow\mathbb{R}^m$ is a linear transformation, then there is a corresponding $m\times n$ matrix $A$ is defined by $A=[L(e_1)\space L(e_2)\space\dots\space L(e_n)]_{m\times n}$

Ex: let $L:\mathbb{R}^3\rightarrow\mathbb{R}^2$ be a linear transformation defined by $L=(\begin{bmatrix} x_1 \\ x_2 \\ x_3 \end{bmatrix})=\begin{bmatrix} x_1+2x_2+3x_3\\ 2x_1+x_2-3x_3\end{bmatrix}$
$L:\mathbb{R}^3\rightarrow\mathbb{R}^2$
$(x_1,x_2,x_3)\rightarrow(x_1+2x_2+3x_3,2x_1+x_2-3x_3)$
Consider standard bases $S=\{\begin{bmatrix} 1 \\ 0 \\ 0 \end{bmatrix},\begin{bmatrix} 0 \\ 1 \\ 0 \end{bmatrix},\begin{bmatrix} 0 \\ 0 \\ 1 \end{bmatrix}\}$ for $\mathbb{R}^3$ $T=\{\begin{bmatrix} 1 \\ 0 \end{bmatrix},\begin{bmatrix} 0 \\ 1 \end{bmatrix}\}$ of $\mathbb{R}^2$.
Find the matrix representation of $L$ with bases with respect to the bases $S$ and $T$.
$L(\begin{bmatrix} 1 \\ 0 \\ 0 \end{bmatrix})=\begin{bmatrix} 1 \\ 2 \end{bmatrix}$ $L=(\begin{bmatrix} 0 \\ 1 \\ 0 \end{bmatrix})=\begin{bmatrix} 2 \\ 1 \end{bmatrix}$ $L=(\begin{bmatrix} 0 \\ 0 \\ 1 \end{bmatrix})=\begin{bmatrix} 3 \\ -3 \end{bmatrix}$
$A=\begin{bmatrix} 1 & 2 & 3 \\ 2 & 1 & -3 \end{bmatrix}_{2\times 3}$

$L((1,2,3))=(14,-5)$
$\begin{bmatrix} 1 & 2 & 3 \\ 2 & 1 & -3 \end{bmatrix}\begin{bmatrix} 1 \\ 2 \\ 3 \end{bmatrix}=\begin{bmatrix} 14 \\ -5 \end{bmatrix}$
$L(\begin{bmatrix} 1 \\ 0 \\ 0 \end{bmatrix})=\begin{bmatrix} 1 \\ 2 \end{bmatrix}=1\begin{bmatrix} 1 \\ 0 \end{bmatrix}+2\begin{bmatrix} 0 \\ 1 \end{bmatrix}$
$L(e_2)=\begin{bmatrix} 2 \\ 1 \end{bmatrix}=2\begin{bmatrix} 1 \\ 0 \end{bmatrix}+1\begin{bmatrix} 0 \\ 1 \end{bmatrix}$
$L(e_3)=\begin{bmatrix} 3 \\ -3 \end{bmatrix}=3\begin{bmatrix} 1 \\ 0 \end{bmatrix}+(-3)\begin{bmatrix} 0 \\ 1 \end{bmatrix}$
$A=\begin{bmatrix} 1 & 2 & 3 \\ 2 & 1 & -3 \end{bmatrix}$ is a matrix representation of $L$ by considering $S$ and $T$.

Ex: let $T:\mathbb{R}^2\rightarrow\mathbb{R}^2$ be a linear tansformation given by $T((x,y))=(x+y,x-y)$. Find the matrix representation of the linear transformation $T$ with respect to the bases $B_1=\{(1,0),(0,1)\}$ and $B_2=\{(1,1),(1,-1)\}$ respectively.
$T((1,0))=(1,1)=a(1,1)+b(1,-1)$
$T((0,1))=(1,-1)=c(1,1)+d(1,-1)$
$(a+b,a-b)=(1,1)$
$(c+d,c-d)=(1,-1)$
$a+b=1$ $a-b=1$
$c+d=1$ $c-d=-1$
$a=1$ $b=0$
$c=0$ $d=1$
$A=\begin{bmatrix} 1 & 0 \\ 0 & 1\end{bmatrix}$
$T((1,0))=(1,1)=1(1,1)+0(1,-1)$
$T((0,1))=(1,-1)=0(1,1)+1(1,-1)$
$A=\begin{bmatrix} 1 & 0 \\ 0 & 1\end{bmatrix}$
$T((2,3))=(5,-1)$
$\begin{bmatrix} 1 & 0 \\ 0 & 1\end{bmatrix}\begin{bmatrix} 2 \\ 3 \end{bmatrix}=\begin{bmatrix} 2 \\ 3 \end{bmatrix}$
$(5,-1)=1(1,1)+3(1,-1)$

Ex: let $B_1\{(1,0,0),(0,1,0),(0,0,1)\}$ $B_2=\{(1,0,0),(1,1,0),(1,1,1)\}$ be two ordered bases of $\mathbb{R}^3$. Define $T:\mathbb{R}^3\rightarrow\mathbb{R}^3$ by $T(x)=X$ for $x\in \mathbb{R}^3$. Find the matrix representation of $T$ by considering $B_1,B_2$ respectively.
$T((1,0,0))=(1,0,0)=1(1,0,0)+0(1,1,0)+0(1,1,1)$
$T((0,1,0))=(0,1,0)=(-1)(1,0,0)+1(1,1,0)+0(1,1,1)$
$T((0,0,1))=(0,0,1)=0(1,0,0)+(-1)(1,1,0)+1(1,1,1)$
$A=\begin{bmatrix} 1 & -1 & 0\\ 0 & 1 & -1\\ 0 & 0 & 1\end{bmatrix}$ is a matrix representation of $T$ by considering $B_1$ and $B_2$, respectively.