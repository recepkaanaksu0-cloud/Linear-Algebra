Defn: let $V$ and $W$ be vector spaces over $\mathbb{R}$. A map $T:\space V\rightarrow W$ is called a linear transformation if $T(\alpha u+\beta v)=\alpha T(u)+\beta T(u)$. for all $\alpha,\beta\in\mathbb{R}$ and $u,v\in V$.
$T(\alpha u)=\alpha T(u)$
$T(u+v)=T(u)+T(v)$
$f:\space A\rightarrow B$
$A,B\subseteq \epsilon$.

Examples: 
(1) Define $T:\space \mathbb{R}\rightarrow\mathbb{R}^2$ by $T(x)=(x,3x)$ for all $x\in\mathbb{R}$. Is $T$ a linear transformation?
For all $\alpha,\beta\in\mathbb{R}$ and $u,v\in\mathbb{R}$ $T(\alpha u+\beta v)=\alpha T(u)+\beta T(v)$
$T(\alpha u+\beta v)=(\alpha u+\beta v,3(\alpha u+\beta v))$
$=(\alpha u+\beta v,3\alpha u+3\beta v)$
$=(\alpha u,3\alpha u)+(\beta v,3\beta v)$
$\alpha T(u)+\beta T(v)=\alpha(u,3u)+\beta(v,3v)$
$=(\alpha u,3\alpha u)+(\beta v,3\beta v)$
=>$T$ is a linear transformation.

(2) Define $T:\space \mathbb{R}^2\rightarrow\mathbb{R}^3$ by $T((x,y))=(x+y,2x-y,x+3y)$. Is $T$ linear transformation?
For all $\alpha,\beta\in\mathbb{R}$ and $u,v\in\mathbb{R}$ $T(\alpha u+\beta v)=\alpha T(u)+\beta T(v)$
$u=(x,y)$
$v=(z,t)\in\mathbb{R}^2$
$T(\alpha u+\beta v)=T(\alpha(x,y)+\beta(z,t))$
$T((\alpha x+\beta z,\alpha y+\beta t))$
$=(\alpha x+\beta z+\alpha y+\beta t,2(\alpha x+\beta z)-(\alpha y+\beta t),\alpha x+\beta z+3(\alpha y+\beta t))$

$\alpha T(u)+\beta T(v)=\alpha T((x,y))+\beta T((z+t))$
$=\alpha(x+y,2x-y,x+3y)+\beta(z+t,2z-t,z+3t)$
$=(\alpha(x+y)+\beta(z+t),\alpha(2x-y)+\beta(2z-t),\alpha(x+3y)+\beta(z+3t))$
=>$T$ is a linear transformation.

(3) Define $T:\space \mathbb{R}^2\rightarrow\mathbb{R}^3$ by $T((x,y))=(x+y+1,2x-y,x+3y)$ for all $(x,y)\in\mathbb{R}^2$. Is $T$ a linear transformation?
let $\alpha=0$,$\beta=0$ 
$(1,1)\in\mathbb{R}^2$ $(1,1)\in\mathbb{R}^2$
$T(\alpha(x,y)+\beta(z,t))=\alpha T((x,y))+\beta T((z,t))$
$T(\alpha(1,1)+\beta(1,1))=T(\alpha+\beta,\alpha+\beta)$
$=(2(\alpha+\beta)+1,2(\alpha+\beta)-(\alpha+\beta),4(\alpha+\beta)$

$T(0,0)=(1,0,0)=T(0(1,1)+0(1,1))$
$T((1,1))=(3,1,4)$ $0T((1,1))+0T((1,1))$
$T(0(1,1)+0(1,1))\neq0T(1,1)+0T(1,1)$
$(1,0,0)\neq(0,0,0)+(0,0,0)$
=>$T$ is not a linear transformation.

Proposition:
let $T:\space V\rightarrow W$ be a linear transformation. Suppose that $O_V$ is the zero vector in $V$ and $O_W$ is the zero vector in $W$. Then $T(O_V)=O_W$.
$T$ is a linear transformation. $\rightarrow$  $T(O_V)=O_W$.
