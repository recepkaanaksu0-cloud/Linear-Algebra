$$
\textbf{Theorem:} \quad A, B, C \in \mathbb{R}^{m \times n}, \quad k, l \in \mathbb{R}
$$

$$
\begin{aligned}
(1)\quad & A + B = B + A \\
(2)\quad & (A + B) + C = A + (B + C) \\
(3)\quad & k(lA) = (kl)A \\
(4)\quad & (k + l)A = kA + lA
\end{aligned}
$$

$$
\textbf{Definition (Additive Inverse):} \quad A \in \mathbb{R}^{m \times n}
$$

$$
\begin{aligned}
(1)\quad & -A = (-1)A \quad \text{(Additive inverse)} \\
(2)\quad & A + 0 = A = 0 + A \quad \text{(Zero matrix is additive identity)}
\end{aligned}
$$

$$
\textbf{Matrix Multiplication:} \quad A \in \mathbb{R}^{m \times n}, \quad B \in \mathbb{R}^{n \times r}
$$

$$
AB = C \in \mathbb{R}^{m \times r}, \quad c_{ij} = \sum_{k=1}^{n} a_{ik} b_{kj}
$$

$$
\text{Product AB is defined iff columns of A = rows of B}
$$

$$
\textbf{Definition:} \quad \text{A and B commute if } AB = BA
$$

$$
\textbf{Remark:} \quad A \in \mathbb{R}^{n \times n} \Rightarrow AI_n = I_nA = A
$$

$$
\text{For any } d \in \mathbb{R}, \quad dI_n = \begin{bmatrix} d & 0 \\ 0 & d \end{bmatrix} \quad \text{commutes with all square matrices}
$$

$$
\text{Matrix multiplication is not commutative in general}
$$

$$
A = \begin{bmatrix} 1 & 1 \\ 0 & 0 \end{bmatrix}, \quad
B = \begin{bmatrix} 1 & 0 \\ 1 & 0 \end{bmatrix}
$$

$$
\textbf{Theorem: Matrix Multiplication Properties}
$$

$$
\begin{aligned}
(1)\quad & (AB)C = A(BC) \quad \text{(Associativity)} \\
(2)\quad & (kA)B = A(kB) \\
(3)\quad & A(B + C) = AB + AC \quad \text{(Distributivity)} \\
(4)\quad & I_n A = A = A I_n \\
(5)\quad & D = \text{diag}(d_1, \dots, d_n) \Rightarrow \text{Row } i \text{ of } DA = d_i \cdot \text{Row } i \text{ of } A
\end{aligned}
$$

$$
\textbf{Definition: Special Matrices}
$$

$$
\begin{aligned}
\text{Symmetric: } & A^t = A \\
\text{Skew-symmetric: } & A^t = -A \\
\text{Orthogonal: } & AA^t = A^t A = I
\end{aligned}
$$

$$
A = \begin{bmatrix}
1 & 2 & 3 \\
2 & 4 & -1 \\
3 & -1 & 4
\end{bmatrix}, \quad
A^t = \begin{bmatrix}
1 & 2 & 3 \\
2 & 4 & -1 \\
3 & -1 & 4
\end{bmatrix}
$$

$$
\text{Let } A = \begin{bmatrix} a & b \\ c & d \end{bmatrix} \in M_2(\mathbb{R}) \text{ be nonzero, symmetric and skew-symmetric}
$$

$$
A \neq 0, \quad A = A^t = -A
$$

$$
\textbf{Definition:}
$$

$$
\begin{aligned}
\text{Nilpotent: } & A^k = 0 \text{ for some } k \in \mathbb{N}^+ \\
\text{Idempotent: } & A^2 = A
\end{aligned}
$$

$$
\text{Examples:} \quad
\text{Nilpotent: } \begin{bmatrix} 0 & 0 \\ 0 & 0 \end{bmatrix}, \quad
\text{Idempotent: } \begin{bmatrix} 1 & 0 \\ 0 & 1 \end{bmatrix}
$$