Defn: $A$ vector space over $\mathbb{R}$ denoted $V(\mathbb{R})$ is a non-empty set satisfying the following:
(1) Vector Addition: Every pair $u, v ∈ V$ there corresponds a unique element $u \oplus v ∈ V$ such that
	(a) $u \oplus v=v \oplus u$ (commutative law)
	(b) $(u \oplus v)\oplus w =u \oplus(v \oplus w)$ for all $u, v, w, ∈V$. (associative law)
	(c) There is a unique element $0 ∈ V$ (the zero vector) such that $u \oplus 0= u$ for every $u ∈ V$. (called the additive identity)
	(d) For every $u∈V$ there is a unique element $-u∈V$ such that $u\oplus -u=0$. (called the additive inverse)

(2) Scaler Multiplication: For each $u∈V$ and $\alpha ∈\mathbb{R}$, there corresponds a unique element $\alpha\odot u$ in $V$ such that
	(a) $\alpha\odot(\beta\odot u)=(\alpha .\beta)\odot u$ for every $\alpha, \beta ∈\mathbb{R}$ and $u∈V$.
	(b) $1\odot u=u$ for every $u∈V$ where $1∈\mathbb{R}$.

(3) Distributive Laws: For any $\alpha, \beta ∈\mathbb{R}$ and $u, v ∈V$ the following distributive laws hold:
	(a) $\alpha \odot(u\oplus v)=(\alpha \odot u)\oplus(\alpha \odot v)$
	(b) $(\alpha +\beta)\odot u=(\alpha \odot u)\oplus (\beta \odot u)$
Note: The number $0$ is the element of $\mathbb{R}$ where 




Remark: The elements of $\mathbb{R}$ are called scalars and that of $V$ are called vectors. And the vector space $(v, \odot, \mathbb{R}, +, \cdot, \odot)$
If you consider $ℂ$ in place of $\mathbb{R}$, then the vector space is called a complex vector space.

Theorem: let $v$ be a vector space over $\mathbb{R}$. Then
(1) $u\odot v=u$ implies $v=0$.
(2) $\alpha \odot u = 0$ if and only if either $u=0∈V$ or $\alpha =0∈\mathbb{R}$.
(3) $(-1)\odot u = -u$ for all $u∈V$.