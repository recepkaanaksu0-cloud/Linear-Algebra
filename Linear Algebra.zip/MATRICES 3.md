Remark: let $Ax=b$ be a linear system with $m$ equations and $n$ unknowns.
Then the row reduced echelon form of $A$ agrees with the first $n$ columns of $[A\space b]$, and hence 
$row-rank (A) ≤ row-rank ([A\space b])$.

Ex: Consider the linear system of equations:
$x+y+z=3$
$x+2y+2z=5$
$3x+4y+4z=12$

$[A\space b]=\begin{bmatrix} 1 & 1 & 1 :& 3\\ 1 & 2 & 2 :& 5\\ 3 & 4 & 4 :& 12\end{bmatrix}\begin{bmatrix} 1 & 1 & 1 :& 3\\ 0 & 1 & 1 :& 2\\ 0 & 0 & 0 :& 1\end{bmatrix}$

Remark: Consider a matrix $A$. After application of a finite number of elementary column operations to the matrix $A$, we can have the matrix $B$ which has the following properties.
(1) The first non-zero entry in each column is 1.
(2) A column containing only $0$'s comes after all columns with at least one non-zero entry
(3) The first non-zero entry (the leading term) in each non-zero columns moves down in successive columns.

Therefore, we can define column rank of $A$ as the number non-zero columns of $B$. Moreover, 
$row-rank (A) = column-rank (A)$
Defn: The number of non-zero rows in the row reduced echelon form of a matrix $A$ is called the rank of $A$ and denoted by $rank(A)$.

Theorem: [Existance and Non-existance]
Consider the linear system $Ax=b$ where $A$ is $m\times n$ matrix and $X$, $b$ are column matrices with orders $n\times1$ and $m\times1$, respectively.
Suppose $rank(A)=r$ and $rank([A\space b])=ra$. Then exactly one of the following statements holds: 
(1) If $ra = r < n$, the set of solutions of the linear system is an infinite set.
(2) If $ra = r = n$, the solution set of the linear system has a unique solution.
(3) If $r < ra$, the linear system has no solution.

Ex:
(1) Solve the linear system.
$x+y+z=3$
$x+2y+2z=5$
$3x+4y+4z=11$

$[A\space b]=\begin{bmatrix} 1 & 1 & 1 :& 3\\ 1 & 2 & 2 :& 5\\ 3 & 4 & 4 :& 11\end{bmatrix}=>\begin{bmatrix} 1 & 1 & 1 :& 3\\ 0 & 1 & 1 :& 2\\ 0 & 0 & 0 :& 0\end{bmatrix}R12(-1)=>\begin{bmatrix} 1 & 0 & 0 :& 1\\ 0 & 1 & 1 :& 2\\ 0 & 0 & 0 :& 0\end{bmatrix}$
$rank(A)=2$
$rank([A\space b])=2$

(2) Solve the linear system.
$y+z=2$
$2x+3z=5$
$x+y+z=3$
$[A\space b]=\begin{bmatrix} 0 & 1 & 1 :& 2\\ 2 & 0 & 3 :& 5\\ 1 & 1 & 1 :& 3\end{bmatrix}=>\begin{bmatrix} 1 & 0 & 3/2 :& 5/2\\ 0 & 1 & 1 :& 2\\ 0 & 0 & 1 :& 1\end{bmatrix}=>\begin{bmatrix} 1 & 0 & 0 :& 1\\ 0 & 1 & 0 :& 1\\ 0 & 0 & 1 :& 1\end{bmatrix}$
$rank([A\space b])=3$
$rank(A)=3=n$"the number of the unknowns"

Remark: let A be an $m\times n$ matrix and consider the linear system $Ax=b$. Then the linear system $Ax=b$ is consistent if $rank(A)=rank([A\space b])$.

Corollary: let A be an $m\times n$ matrix. Then the homogenous system $Ax=0$ has a non-trivial solution if $rank(A) < n$.

Ex:
$a+2b=0$
$2a+4b=0$
$A=\begin{bmatrix} 1 & 2\\2 & 4 \end{bmatrix}  X=\begin{bmatrix} a\\ b\end{bmatrix}$
$\begin{bmatrix} 1 & 2 :&0\\2 & 4 :&0\end{bmatrix}=>\begin{bmatrix} 1 & 2 :&0\\0 & 0 :&0\end{bmatrix}$
$rank(A)=1<n=2$
$-2b, b | t ∈ \mathbb{R}$
Prop: Consider the linear system $Ax=b$. Then the two statements given below cannot hold together.
(1) The system $Ax=b$ has a unique solution for every $b$.
(2) The system $Ax=0$ has a non-trivial solution.