Recall the following:
The linear system $Ax=b$ has unique solution for every $b$ iff $A^{-1}$ exists.

A has an inverse iff $det(A)\neq 0$. Thus, $Ax=b$ has a unique solution for every b iff $det(A) \neq 0$.

Theorem: (Cramer's Rule)
let Ax=b be a linear system with n equations in n unknowns. If $det(A)\neq 0$.
the unique solution of the system is $X_j=det(A_j)/det(A)$ for $j=1, \dots, n$
where $A_j$ is the matrix obtained from A by replacing the $j^{th}$ column of A by the column vector b.

Ex: Suppose that
$A=\begin{bmatrix} 1 & 2 & 3\\ 2 & 3 & 1\\ 1 & 2 & 2\end{bmatrix}$ and $b=\begin{bmatrix} 1\\ 1\\ 1 \end{bmatrix}$
use Cramer's Rule to find vector $X$ such that $Ax=b$.

Solution:
$A.\begin{bmatrix} x_1\\ x_2\\ x_3 \end{bmatrix}=b$
$det(A)=(-1)^{1+1}.1.\begin{vmatrix} 3 & 1\\ 2 & 2\end{vmatrix}+(-1)^{1+2}.2.\begin{vmatrix} 2 & 1\\ 1 & 2\end{vmatrix}+(-1)^{1+3}.3\begin{vmatrix} 2 & 3\\ 1 & 2\end{vmatrix}$
$X_1=det(A_1)/1=-1,\space A_1=\begin{bmatrix} 1 & 2 & 3\\ 1 & 3 & 1\\ 1 & 2 & 2\end{bmatrix}\space det(A_1)=-1$
$X_2=det(A_2)/1=1,\space A_2=\begin{bmatrix} 1 & 1 & 3\\ 2 & 1 & 1\\ 1 & 1 & 2\end{bmatrix}\space det(A_2)=1$
$X_3=\begin{bmatrix} 1 & 2 & 1\\ 1 & 3 & 1\\ 1 & 2 & 1\end{bmatrix}/1=0$

$X=\begin{bmatrix} -1\\ 1\\ 0 \end{bmatrix}$
