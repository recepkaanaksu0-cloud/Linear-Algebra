Defn: (Row Reduced Echelon Matrix)
A matrix which is in the row reduced echelon form is called a row reduced echelon matrix.

Defn: (Back Substitution/Gauss Jordan Method)
The procedure to get first steo-p from the last step is called back substitution.
The elimination process applied obtain the row reduced echelon form of the augmented matrix is called the Gauss Jordan Elimination.
!! That is the Gauss Jordan Elimination method consists of both the forward elimination and the backward substitution.

---
### Method to get the row-reduced echelon form of a given matrix 


let $A$ be an $m\times n$ matrix. Then the following method is used to obtain the row-reduced echelon form of the matrix $A$.

Step1: Consider the column of the matrix A.
If all the entries in the first column are zero, move to the second column.
Else, find a row, say $i^{th}$ row which contains a non-zero entry in the first column

Now, interchange the first row with the $i^{th}$ row. Suppose the non-zero entry in the (1, 1)-position is $a\neq0$. Divide the whole row by a so that the (1, 1)-entry of the new matrix is 1.

Now, use the 1 to make all entries below this 1, equal 0.

Step2: If all entries in the first column after the first step are zero, consider the right mx(n-1) submatrix of the matrix obtained in Step1, and proceed as in Step1.

Step3: Keep repeating this process till we reach a stage where all enties below a particular row, say r, are zero.

Suppose at this stage, we have obtained a matrix C Then C has the following form.

(1) The first non-zero entry in each row of C and the columns containing these leading term are the leading columns.

The entries of C below the leading term are all zero.

Step4: Now use the leading term in the $r^{th}$ row to make all entries in the $r^{th}$ leading column equal to zero.

Step5: Next, use the leading term in the $(r-1)^{th}$ row to make all entries in the $(r-1)^{th}$ leading column equal to zero and continue till we come to the first leading term or leading column. The final matrix is the row-reduced echelon form of the matrix A.

Ex: Find the row reduce echelon form of the matrix
$A=\begin{bmatrix}10 & 8 & 6 & 4\\2 & 0 & -2 & -4\\-6 & -8 & -10 & -12\\-2 & -4 & -6 & -8\end{bmatrix}$

$R_{12}R_3(-1)R_4(-1)$=>

$A=\begin{bmatrix}2 & 0 & -2 & -4\\10 & 8 & 6 & 4\\6 & 8 & 10 & 12\\2 & 4 & 6 & 8\end{bmatrix}$

$R_1(1/2)R_2(1/2)R_3(1/2)R_4(1/2)$=>
$A=\begin{bmatrix}1 & 0 & -1 & -2\\5 & 4 & 3 & 2\\3 & 4 & 5 & 6\\1 & 2 & 3 & 4\end{bmatrix}$

$R_{21}(-5)R_{31}(-3)R_{41}(-1)$=>
$A=\begin{bmatrix}1 & 0 & -1 & -2\\0 & 4 & 8 & 12\\0 & 4 & 8 & 12\\0 & 2 & 4 & 6\end{bmatrix}$

$R_2(1/4)R_3(1/4)R_4(1/2)$=>
$A=\begin{bmatrix}1 & 0 & -1 & -2\\0 & 1 & 2 & 3\\0 & 1 & 2 & 3\\0 & 1 & 2 & 3\end{bmatrix}$

$R_{32}(-1)R_{42}(-1)$=>
$A=\begin{bmatrix}1 & 0 & -1 & -2\\0 & 1 & 2 & 3\\0 & 0 & 0 & 0\\0 & 0 & 0 & 0\end{bmatrix}$
=> The row reduced echelon form of $A$.
Theorem: The row reduced echelon form of a matrix is UNIQUE.

---
### Elementary Matrices
Defn: A square matrix $E$ of order $n$ is called an elementary matrix if is obtained by applying exactly one elementary row operation to the identity matrix $In$.

Ex: 
$E_{23}=\begin{bmatrix}1 & 0 & 0\\0 & 0 & 1\\0 & 1 & 0\end{bmatrix}$

$E_1(c)=\begin{bmatrix}c & 0 & 0\\0 & 1 & 0\\0 & 0 & 1\end{bmatrix}$

$E_{23}(c)=\begin{bmatrix}1 & 0 & 0\\0 & 1 & c\\0 & 0 & 1\end{bmatrix}$

Ex:
$A=\begin{bmatrix}1 & 2 & 3 & 0\\2 & 0 & 3 & 4\\3 & 4 & 5 & 6\end{bmatrix}$

$R_{23}=>\begin{bmatrix}1 & 2 & 3 & 0\\3 & 4 & 5 & 6\\2 & 0 & 3 & 4\end{bmatrix}=E_{23} A$ 

$E_{23} A=\begin{bmatrix}1 & 0 & 0\\0 & 0 & 1\\0 & 1 & 0\end{bmatrix}\begin{bmatrix}1 & 2 & 3 & 0\\2 & 0 & 3 & 4\\3 & 4 & 5 & 6\end{bmatrix}=\begin{bmatrix}1 & 2 & 3 & 0\\3 & 4 & 5 & 6\\2 & 0 & 3 & 4\end{bmatrix}$

That is, interchanging the two rows of the matrix $A$ is same as multiplying on the left by the corresponding elementary matrix. In other words the left multiplication of elementary matrices to a matrix results in elementary row operations.

Ex: Consider the augmented matrix 
$[A\space b]= \begin{bmatrix} 0 & 1 & 1 :& 2\\ 2 & 0 & 3 :& 5\\ 1 & 1 & 1 :& 3\end{bmatrix}$
Find the row reduced echelon form of $[A\space b]$
$y+z=2$
$2x+3z=5$
$x+y+z=3$

$[A\space b] R_{13}=>\begin{bmatrix} 1 & 1 & 1 :& 3\\ 2 & 0 & 3 :& 5\\0 & 1 & 1 :& 2\end{bmatrix}$

$R_{21}(-2)=>\begin{bmatrix} 1 & 1 & 1 :& 3\\ 0 & -2 & 1 :& -1\\0 & 1 & 1 :& 2\end{bmatrix}$

$R_{23}=>\begin{bmatrix} 1 & 1 & 1 :& 3\\0 & 1 & 1 :& 2\\ 0 & -2 & 1 :& -1\end{bmatrix}$

$R_{12}(-1)=>\begin{bmatrix} 1 & 0 & 0 :& 1\\0 & 1 & 1 :& 2\\ 0 & 0 & 3 :& 3\end{bmatrix}$

$R_3(1/3)=>\begin{bmatrix} 1 & 0 & 0 :& 1\\0 & 1 & 1 :& 2\\ 0 & 0 & 1 :& 1\end{bmatrix}$

$R_{23}(-1)=>\begin{bmatrix} 1 & 0 & 0 :& 1\\0 & 1 & 0 :& 1\\ 0 & 0 & 1 :& 1\end{bmatrix}$

$E_{23}(-1) E_3(1/3) E_{32}(2) E_{12}(-1) E_{23} E_{21}(-2) E_{13} [A b]$

$\begin{bmatrix} 1 & 0 & 0\\0 & 1 & 0\\ 0 & 0 & 1\end{bmatrix}\begin{bmatrix} x\\ y\\ z\end{bmatrix}=\begin{bmatrix} 1\\ 1\\ 1\end{bmatrix}, 1=x=y=z$

---
### RANK OF A MATRIX
In previous sections, we solved linear systems using Gauss Eliminization Method or the Gauss Jordan Method. In examples considereed, we have encountered three possibilities, namely:

(1) Existance of a unique solution
(2) Existance of an infinite number of solutions, and
(3) No solution.

Based on the above possibilities, we have following definition.
Defn: (Consistent, Inconsistent)
A linear system is called consistent if it admits a solution and is called inconsistent if it has no solution.
!! Recall that the row reduced echelon form of a matrix is unique form of a matrix is unique and so the number of non-zero rows is a unique number.
Also, note that the number of non-zero rows in either the row reduced form or the row reduced echelon form of a matrix are same.

---