Remark:
let $A$ be a matrix of rank $r$. Then the non-zero rows in the row reduced echelon form of $A$ are linearly independent and they form a basis of the row space of $A$.

Theorem: let $\{v_1,v_2,\dots,v_n\}$ be a basis of a given vector space $V$. If $\{w_1,w_2,\dots,w_m\}$ is called a set of vectors from $V$ with $m>n$ then this set is linearly dependent.

Remark: let $V$ be a vector subspace of $\mathbb{R}^n$ with spanning set $S$. We give a method of finding a basis of $V$ from $S$.
(1) Construct a matrix $A$ whose rows are the vectors in $S$.
(2) Use only the elementary row operations $R_i(c)$ and $R_{ij}(c)$ get the row reduced form $B$ of $A$. (In fact we just need to make as many zero rows as possible)
(3) let $\mathbb{B}$ be the set of vectors in $S$ in corresponding to the non-zero rows of $B$. Then the set $\mathbb{B}$ is a basis of $L(S)=V$.

Ex: let $S=\{(1,1,1,1),(1,1,-1,1),(1,1,0,1),(1,-1,1,1)\}$ be subset $\mathbb{R}^4$. Find basis of $L(S)$.

$A=\begin{bmatrix} 1 & 1 & 1 & 1\\ 1 & 1 & -1 & 1\\ 1 & 1 & 0 & 1 \\ 1 & -1 & 1 & 1\end{bmatrix}$
$R_{21}(-1)R_{31}(-1)R_{41}(-1)$
$\begin{bmatrix} 1 & 1 & 1 & 1\\ 0 & 0 & -2 & 0\\ 0 & 0 & -1 & 0 \\ 0 & -2 & 0 & 0\end{bmatrix}$ 
$R_{23}(-2)R_4(-1/2)$
$\begin{bmatrix} 1 & 1 & 1 & 1\\ 0 & 0 & 0 & 0\\ 0 & 0 & -1 & 0 \\ 0 & 1 & 0 & 0\end{bmatrix}$
$R_3(-1)R{14}(-1)$
$\begin{bmatrix} 1 & 0 & 1 & 1\\ 0 & 0 & 0 & 0\\ 0 & 0 & 1 & 0 \\ 0 & 1 & 0 & 0\end{bmatrix}$
$R_{13}(-1)$
$\begin{bmatrix} 1 & 0 & 0 & 1\\ 0 & 0 & 0 & 0\\ 0 & 0 & 1 & 0 \\ 0 & 1 & 0 & 0\end{bmatrix}=B$
$\mathbb{B}=\{(1,1,1,1),(1,1,0,1),(1,-1,1,1)\}$
$\mathbb{B}_1=\{(1,1,1,1),(1,1,-1,1),(1,-1,1,1)\}$

Corrollary: let $V$ be a finite dimensional vector space. Then any two of $V$ have the same number of vectors.

Defn: (Dimension of a vector space)
The dimension of a finite dimensional vector space $V$ is the number of vectors in a basis of $V$, denoted by $dim(V)$.