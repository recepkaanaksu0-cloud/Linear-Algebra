Defn: (Linear Span)
let $V$ be a real vector space and $S=$ $\{u_1,u_2,\dots,u_3\}$ be an non-empty subset of $V$. The linear span of $S$ is the set defined by
$L(S)=$ $\{\alpha_1 u_1+\dots+\alpha_n u_n |\alpha i∈\mathbb{R}^3;1≤i≤n\}$
If $S$ is an empty set, we define $L(S)=\{0\}$.

Examples: Note that $(4,5,5)$ is a linear combination of $(1,0,0)$,$(1,1,0)$ and $(1,1,1)$ since
$(4,5,5)=a(1,0,0)+b(1,1,0)+c(1,1,1);a,b,c∈\mathbb{R}^3$
$=(a,0,0)+(b,b,0)+(c,c,c)$
$a+b+c=4$
$b+c=5$
$c=5$
$a=-1,b=0,c=5$
$(4,5,5)=(a+b+c,b+c,c)=>(4,5,5)=(-1)(1,0,0)+(0)(1,1,0)+(1,1,1)$

(2) Is $(4,5,5)$ a linear combination of $(1,2,3)$, $(-1,1,4)$ and $(3,3,2)$?
$(4,5,5)=a(1,2,3)+b(-1,1,4)+c(3,3,2)$
$(4,5,5)=(a-b+3c, 2a+b+3c, 3a+4b+2)$
$a-b+3c=4$
$2a+b+3c=5$
$3a+4b+2c=5$

(3) Is $(4,5,5)$ a linear combination of the vectors $(1,2,1)$ and $(1,1,0)$?
$(4,5,5)=a(1,2,1)+b(1,1,0)$
$(4,5,5)=(a+b, 2a+b, a)$
$a=5,a+b=4=>5+b=4=>b=-1$
$2a+b=10-1=9\neq 5$
=> $(4,5,5)$ is not a linear combinaion of the vectors $(1,2,1)$ and $(1,1,0)$.

(4) Determine the linear span of $S=$ $\{(1,1,1),(2,1,3)\}$ over $\mathbb{R}$.
$L(S)=\{\alpha_1(1,1,1)+\alpha_2(2,1,3)|\alpha_1,\alpha_2 ∈\mathbb{R}\}$
$=\{\alpha_1+2\alpha_2,\alpha_1+\alpha_2,\alpha_1+3\alpha_2\}$
$=\{(x,y,z)∈\mathbb{R}^3|2x-y=z\}$

Lemma: (linear Span is a Subspace)
let $V$ be a real vector space and let $S$ be a non-empty subset of $V$.
Then $L(S)$ is a subspace of $V$.

Remark: let $V$ be a real vector space and $W\subset V$ be a subspace of $V$. If $S\subset W$, then $L(S)\subset W$ is a subspace of $W$.

Theorem: let $S$ be a non-empty subset of vector space $V$. Then $L(S)$ is the smallest subspace of $V$ containing $S$.

!! If $S=$ $\{u_1,u_2,\dots,u_m\}$ is a non-empty subset of a vector space $V$, then to check whether the set $S$ is linearly dependent or independent. You need to consider the equation $\alpha_1 u_1+\dots+\alpha_m u_m=0$. If $\alpha_1=\alpha_2=\dots=\alpha_m=0$ is the only solution for this equation then, the set $S$ is a linearly independent subset of $V$. Otherwise $S$ becomes a linearly dependent subset of $V$.

Proposition:
let $V$ be a real vector space.
(1) If $S$ is a linearly independent subset of $V$, then every subset of $S$ is also linearly independent.
(2) The zero vector can not belong to linearly independent set.
(3) If $S$ is a linearly dependent subset of $V$, then every set containing $S$ is also linearly dependent.