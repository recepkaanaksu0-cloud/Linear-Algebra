Theorem:
let $A$ be an $n\times n$ matrix. Then, $A\times Adj(A)=det(A)\times In$. $det(A)\neq 0 => A^{-1}=1/det(A)\times Adj(A)$

Ex: let $A=\begin{bmatrix} 1 & -1 & 0\\ 0 & 1 & 1\\ 1 & 2 & 1\end{bmatrix}$
Solution:
$det(A)=1.(-1)^{1+1}.\begin{vmatrix} 1 & 1\\ 2 & 1\end{vmatrix}+(-1).(-1)^{1+2}.\begin{vmatrix} 0 & 1\\ 1 & 1\end{vmatrix}+0.(-1)^{1+3}.\begin{vmatrix} 0 & 1\\ 1 & 2\end{vmatrix}$ 

$Adj(A)=\begin{bmatrix} -1 & C_{12} & C_{13}\\ C_{21} & C_{22} & C{23}\\ C_{31} & -1 & C{33}\end{bmatrix}=\begin{bmatrix} -1 & 1 & -1\\ 1 & 1 & -1\\ -1 & -3 & 1 \end{bmatrix}$ 

$C_{11}=(-1)^{1+1}.\begin{vmatrix} 1 & 1\\ 2 & 1\end{vmatrix}=-1$
$C_{32}=(-1)^{3+2}.\begin{vmatrix} 1 & 0\\ 0 & 1\end{vmatrix}=-1$

$A^{-1}=1/-2 \times \begin{bmatrix} -1 & 1 & -1\\ 1 & 1 & -1\\ -1 & -3 & 1 \end{bmatrix}=\begin{bmatrix} 1/2 & -1/2 & 1/2\\ -1/2 & -1/2 & 1/2\\ 1/2 & 3/2 & 1/2 \end{bmatrix}$

Theorem: let $A$ and $B$ be square matrice of order $n$. Then $det(AB)=det(A).det(B)$.

Corollary: let $A$ be a square matrix. Then $A$ is non-singular if and if $A$ has on inverse.

Theorem: let $A$ be a square matrix. Then $det(A)=det(A^t)$.
$A=\begin{bmatrix} a & b\\ c & d\end{bmatrix}$
$A^t=\begin{bmatrix} a & c\\ b & d\end{bmatrix}$
$det(A)=(-1)^{1+1}.a.d+(-1)^{1+2}.b.c$
