Notation: For an $n\times n$ matrix $A$ by $A(\alpha |\beta)$, we mean the submatrix $B$ of $A$ which is obtained by deleying the $\alpha^{th}$ row $\beta^{th}$ column.

Ex: Consider the matrix $A=\begin{bmatrix} 1 & 2 & 3\\ 1 & 3 & 2\\ 2 & 4 & 7\end{bmatrix}$ then $A(1|2)=\begin{bmatrix} 1 & 2 \\ 2 & 7\end{bmatrix}$ 
Defn: (Determinant of a square matrix)
let $A$ be a square matrix of order $n$. With $A$, we associate inductively (onn) a number, called the determinant of $A$, written $det(A)$ (or $|A|$) by
$$
\text{det}(A) = 
\begin{cases} 
a & \text{; if } A = [a] \quad (n = 1) \\
\sum_{j=1}^{n} (-1)^{1+j} a_{1j} \cdot \text{det}(A(1/j)) & \text{; otherwise}
\end{cases}
$$
Defn: (Minor, cofactor of a matrix)
The number of det $(A(i|j))$ is called $(i, j)^{th}$ minor of $A$. We write $A_{ij}=det(A(i|j))$
The $(i, j)^{th}$ cofactor of $A$ denoted $C_{ij}$ is the number $(-1)^{i+j} A_{ij}$.

Ex: let $A=\begin{bmatrix} a_{11} & a_{12} \\ a_{21} & a_{22} \end{bmatrix}$ then $det(A)=\sum_{j=1}^{n=2}(-1)^{1+j}a_{1j}\cdot A_{1j}$ 
$A_{11}=det(A(1|1))=a_{22}$
$A_{12}=det(A(1|2))=a_{21}$

	$=(-1)^2a_{11}\cdot a_{22}+(-1)^3a_{12}\cdot a_{21}$
	$=(-1)^{1+1}a_{11}\cdot A_{11}+(-1)^{1+2}a_{12}\cdot A_{12}$
$det(A)=a_{11}\cdot a_{22}-a_{12}\cdot a_{21}$ 

Ex: let $A=A=\begin{bmatrix} a_{11} & a_{12} & a_{13}\\ a_{21} & a_{22} & a_{23}\\  a_{31} & a_{32} & a_{33}\end{bmatrix}$ then $det(A)=\sum_{j=1}^{n=3}(-1)^{1+j}a_{1j}\cdot det(A(i|j))$ 
$det(A)=(-1)^{1+1}a_{11}\cdot det(A(1|1))+(-1)^{1+2}a_{12}\cdot det(A(1|2))+(-1)^{1+3}a_{13}\cdot det(A(1|3))$
$det(A)=a_{11}A_{11}-a_{12}A_{12}+a_{13}A_{13}$
$det(A)=a_{11}(a_{22}a_{33}-a_{23}a_{32})-a_{12}(a_{21}a_{33}-a_{23}a_{31})+a_{13}(a_{21}a_{32}-a_{22}a_{31})$

$A_{11}=det(A(1|1))=a_{22}a_{33}-a_{23}a_{32}=det(\begin{bmatrix} a_{22} & a_{23} \\ a_{32} & a_{33} \end{bmatrix})$
$A_{12}=det(A(1|2))=a_{21}a_{33}-a_{23}a_{31}=det(\begin{bmatrix} a_{21} & a_{23} \\ a_{31} & a_{33} \end{bmatrix})$
$A_{13}=det(A(1|3))=a_{21}a_{32}-a_{22}a_{31}=det(\begin{bmatrix} a_{21} & a_{22} \\ a_{31} & a_{32} \end{bmatrix})$ 

Solution 2:
$det(A)=a_{11}a_{22}a_{33}+a_{21}a_{32}a_{13}+a_{31}a_{12}a_{13}-a_{13}a_{12}a_{31}-a_{23}a_{32}a_{11}-a_{33}a_{12}a_{21}$

Ex: let $A=\begin{bmatrix} 1 & 2 & 3\\ 2 & 3 & 1\\ 1 & 2 & 2\end{bmatrix}$ then $det(A)=(-1)^{1+1}1\cdot \begin{vmatrix} 3 & 1 \\ 2 & 2 \end{vmatrix}+(-1)^{1+2}2\cdot \begin{vmatrix} 2 & 1 \\ 1 & 2 \end{vmatrix}+(-1)^{1+3}3\cdot \begin{vmatrix} 2 & 3 \\ 1 & 2 \end{vmatrix}=4-2\cdot 3+3\cdot 1=1$

Homework: Find the determinant of matrix $A=\begin{bmatrix} 1 & 2 & 7 & 8\\ 0 & 4 & 3 & 2\\ 0 & 0 & 2 & 3 \\ 0 & 0 & 0 & 5\end{bmatrix}$.
Defn: A matrix $A$ is said to be a singular matrix if $det(A)=0$. It is called to be non-singular if $det\neq 0$.

Theorem: let A be an $n\times n$ matrix. Then:
	(1) If $B$ is obtained from $A$ by interchanging two rows. Then;
		$det(B)=-det(A)$
	(2) If $B$ is obtained from $A$ by multiplying a row by $c$. Then;
		$det(B)=c\cdot det(A)$
	(3) If all the elements of one row or column of $A$ are zero. Then;
		$det(A)=0$
	(4) If $B$ is obtained from $A$ by reducing the $j^{th}$ row by itself plus k times the $i^{th}$ row where $i\neq j$. Then;
		$det(B)=det(A)$
	(5) If $A$ is a square matrix having two rows equal. Then;
		$det(A)=0$

Defn: (Adjoint of a matrix)
let $A$ be an $n\times n$ matrix. The matrix $B=[b_{ij}]$ with $b_{ij}=C_{ij}$[^1] for $1≤i≤j≤n$ is called adjoint of $A$ denoted by $Adj(A)$

Ex: $A=\begin{bmatrix} 1 & 2 & 3\\ 2 & 3 & 1\\ 1 & 2 & 2\end{bmatrix}$
$Adj(A)=\begin{bmatrix} C_{11} & C_{12} & C_{13}\\C_{21} & C_{22} & C_{23}\\C_{31} & C_{32} & C_{33}\end{bmatrix}^{t}$
$C_{11}=(-1)^{1+1}\cdot A_{11}$
$C_{11}=A_{11}=det(A(1|1))=det(\begin{bmatrix} 3 & 1 \\ 2 & 2 \end{bmatrix})=4$
$C_{12}=(-1)^{1+2}\cdot \begin{vmatrix} 2 & 1 \\ 1 & 2 \end{vmatrix}=-3$
$C_{13}=\vdots$
$\vdots$

$Adj(A)=\begin{bmatrix} C_{11} & \dots \\ C_{12} & \dots \\ C_{13} & \dots \end{bmatrix}$
$Adj(A)=\begin{bmatrix} 4 & 2 & -7\\ -3 & -1 & 5\\ 1 & 0 & -1\end{bmatrix}$

[^1]: $(j, i)^{th}$ cofactor of $A$
