Defn: (Inverse Linear Tranformation)
let $T:V\rightarrow W$ be a linear transformation. If the map $T$ is onto and one-to-one then the map $T^{-1}:W\rightarrow V$ defined by $T^{-1}(W)=V$ whenever $T(V)=W$ is called the inverse of the linear transformation $T$.

Ex: Define $T:\mathbb{R}^2\rightarrow\mathbb{R}^2$ by $T((x,y))=(x+y,x-y)$.
$T$ is a linear transformation onto one-to-one
$T^{-1}:\mathbb{R}^2\rightarrow\mathbb{R}^2$      $TT^{-1}=I_{\mathbb{R}^2}=T^{-1}T$
$T((x,y))=(x+y,x-y)$
$T^{-1}T((x,y))=T^{-1}(x+y,x-y)$
$(x,y)=T^{-1}(x+y,x-y)$
$x+y=a$   $x-y=b$
$x=a/2+b/2$   $y=a/2-b/2$
$T^{-1}(a,b)=(a/2+b/2,a/2-b/2)$
