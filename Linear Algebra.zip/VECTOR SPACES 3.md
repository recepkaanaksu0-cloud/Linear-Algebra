Ex:
(2) let $S=\{(x,y,z)∈\mathbb{R}^3|x+y=0\}$
Is $S$ a subspace of $\mathbb{R}^3$?
	(i) $S\neq\emptyset$
	$(1,1,2) 1+1-2=0$
	=>$(1,1,2)∈S => SS\neq\emptyset$
	(ii) $S≤\mathbb{R}^3$
	the elements of $S$ are elements of $\mathbb{R}^3$, so $S≤\mathbb{R}^3$.
	(iii) For every $\alpha,\beta∈\mathbb{R}$ and for every $u,v∈S$,$\alpha u+\beta u∈S$
	$\alpha,\beta∈\mathbb{R}$
	$u=(x_1,y_1,z_1)$
	$v=(x_2,y_2,z_2)$
	$\downarrow$
	$\alpha u+\beta v=\alpha(x_1,y_1,z_1)+\beta(x_2,y_2,z_2)$
	$=(\alpha x_1,\alpha y_1,\alpha z_1)+(\beta x_2,\beta y_2,\beta z_2)$
	$=(\alpha x_1+\beta x_2,\alpha y_1+\beta y_2,\alpha z_1+\beta z_2)$
	=> $\alpha u+\beta v ∈S$
	=> $S$ is a real subspace of $\mathbb{R}^3$.
H.w:
$S=\{(x,y,z)∈\mathbb{R}^3|x+y+z=3\}$
Is $S$ a subspace of $\mathbb{R}^3$?
