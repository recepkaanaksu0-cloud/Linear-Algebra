Defn: (Inverse of a Matrix)
let A be a square matrix of order n.

(1) A square matrix $B$ is said to be a left inverse of A if $BA=In$.
(2) A square matrix $C$ is called a right inverse of A if $AC=In$.
(3) A matrix $A$ is said to be invertible if there exists a matrix $B$ such that $AB=BA=In$.

Lemma: let A be an $n\times n$ matrix.
Suppose that there exist $n\times n$ matrices $B$ and $C$ such that $AB=In$ and $CA=In$, then $B=C$.

Proof: $B=InB=(CA)B=C(AB)=CIn=C$

Remark:
(1) If a matrix $A$ is invertible, then the inverse of $A$ is unique.
(2) As the inverse of a matrix $A$ is unique, we denote it $A^{-1}$. That is. $AA^{-1}=I=A^{-1}A$.

Theorem: let $A$ and $B$ be two matrices with inverses $A^{-1}$ and $B^{-1}$,respectively. Then
(1) $(A^{-1})^{-1}=A$
(2) $(AB)^{-1}=B^{-1}A^{-1}$
(3) $(A^t)^{-1}=(A^{-1})^t$

Proof:
(1) $AA^{-1}=I=A^{-1}A$
let $A^{-1}=B$
=> $AB=I=BA$
=> $B^{-1}=A$
=> $(A^{-1})^{-1}=A$

(2) $(AB)(AB)^{-1}=I=(AB)^{-1}(AB)$
=> $(AB)(B^{-1}A^{-1})=In=(B^{-1}A^{-1})(AB)$
=> $A(BB^{-1})A^{-1}=(AI)A^{-1}=AA^{-1}=I$

(3) $AA^{-1}=I=A^{-1}A$
=> $(AA^{-1})^t=I^t=(A^{-1}A)^t$
=> $(A^{-1})^tA^t=I=A^t(A^{-1})^t$
=> $(A^t)^{-1}=(A^{-1})^t$
