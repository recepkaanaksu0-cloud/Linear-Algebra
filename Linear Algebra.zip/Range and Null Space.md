Defn: (Range and Null Space)
let $V,W$ be finite dimensional vector spaces over the real numbers. and $T:V\rightarrow W$ be a linear transformation.
(1) $R(T)\{T(x)|x\in V\}$ (Range of $T$)
(2) $N(T)=\{x\in V|T(x)=Q_W\}$ (Kernel of $T$)

The space $R(T)$ is called the range of $T$. The space $N(T)$ is called the null space of $T$.

Ex: Determine the range and the null space of the linear transformation $T:\mathbb{R}^3\rightarrow\mathbb{R}^4$ with $T((x,y,z))=(x-y+z,y-z,x,2x-5y+5z)$.
$\{(1,0,0),(0,1,0),(0,0,1)\}$ is a basis of $\mathbb{R}^3$.
$R(T)=L(T(1,0,0),T(0,1,0),T(0,0,1))$
$R(T)=L((1,0,1,2),(-1,1,0,-5),(1,-1,0,5))$
$=L((1,0,1,2),(1,-1,0,5))$
$\{\alpha(1,0,1,2)+\beta(1,-1,0,5)|\alpha,\beta\in\mathbb{R}\}$
$\{\alpha+\beta,-\beta,\alpha,2\alpha+5\beta|\alpha,\beta\in\mathbb{R}\}=\{(x,y,z,w)\in\mathbb{R}^4|x+y-z=0,5y-2z+w=0\}$

$N(T)=\{(x,y,z)\in\mathbb{R}^3|T((x,y,z))=(0,0,0,0)\}$
$=\{(x,y,z)\in\mathbb{R}^3|(x-y+z,y-z,x-2x-5x+5z)=(0,0,0,0)\}$
$=\{(x,y,z)\in\mathbb{R}^3|x-y+z=0,y-z=0,x=0,2x-5y+5z=0\}$
$=\{(x,y,z)|x=0,y=2\}$
$=\{(0,y,y)|y\in\mathbb{R}\}$
$L((0,1,1))$
