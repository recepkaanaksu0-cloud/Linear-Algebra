Examples:
(1) The set $\mathbb{R}$ of all real numbers, with usual addition and multiplication (i.e,$\oplus:=+$ and $\odot:=\cdot$ )      
forms a vector space over $\mathbb{R}$.
($\mathbb{R}^2,\oplus,\mathbb{R},+,\cdot,\odot$)

(2) Consider the set
$\mathbb{R}^2$ =$\{(x,y)|x∈\mathbb{R}$ and $y∈\mathbb{R}\}$
For $x_1,x_2,y_1,y_2 ∈\mathbb{R}$ and $\alpha∈\mathbb{R}$ define
$(x_1,x_2)\oplus(y_1,y_2)=(x_1+y_1,x_2+y_2)$
$\alpha\odot(x_1,x_2)=(\alpha x_1,\alpha x_2)$
Then $\mathbb{R}^2$ is a real vector space.

Proof:
(a) $u\oplus v=v\oplus u$ 
$u=(x_1,x_2);x_1,x_2 ∈\mathbb{R}$
$v=(y_1,y_2);y_1,y_2∈\mathbb{R}$
$u\oplus v=(x_1,x_2)\oplus(y_1,y_2)$
$=(x_1+y_1,x_2+y_2)=(y_1+x_1,y_2+x_2)$
$=(y_1,y_2)\oplus(x_1,x_2)$
$v\oplus u$ 

(b) $(u\oplus v)\oplus w=u\oplus(v\oplus w)$
$u∈\mathbb{R}^2 => u=(x_1,x_2);x_1,x_2∈\mathbb{R}$ 
$v∈\mathbb{R}^2 => v=(y_1,y_2);y_1,y_2∈\mathbb{R}$
$w∈\mathbb{R}^2 => w=(z_1,z_2);z_1,z_2∈\mathbb{R}$
$(u\oplus v)\oplus w=((x_1,x_2)\oplus(y_1,y_2))\oplus(z_1,z_2)$
$=((x_1+x_2)\oplus(y_1+y_2))\oplus(z_1z_2)$
$=((x_1+x_2)+z_1,(y_1+y_2)+z_2)$

(c) There is a unique element $0∈V$ such that $u\oplus 0=u$ for every $u∈V^{\mathbb{R}^2}$.
For every $u=(x_1,x_2)∈\mathbb{R}^2$
$u\oplus 0=(x_1,x_2)\oplus(0, 0)=(x_1,x_2)$
$(x_1+0,x_2+0)=(x_1,x_2)$

let $u=(x_1,x_2)$
$0=(y_1,y_2)$
$(x_1,x_2)\oplus(y_1,y_2)=(x_1,x_2)$
$(x_1+y_1,x_2+y_2)=(x_1,x_2)$
$x_1+y_1=x_1 => y_1=0$
$x_2+y_2=x_2 => y_2=0$
$0=(0,0)$

(d) For every $u∈\mathbb{R}^2$ there is a unique element $-u∈V$ s.t $u\oplus -u=(0,0)$
$u=(x_1,x_2)∈\mathbb{R}$
$-u=(y_1,y_2)$
$(x_1,x_2)\oplus(y_1,y_2)=(0,0)$
$(x_1+y_1,x_2+y_2)=(0,0)$
$y_1=-x_1$
$y_2=-x_2$
$=>-u=(-x_1,x_2)∈\mathbb{R}^2$.

Scaler Multiplication
(?)(1) $\alpha\odot(\beta\odot u)=(\alpha\beta)\odot u$ for every $\alpha,\beta ∈\mathbb{R}^2$.
$u=(x_1,x_2)∈\mathbb{R}^2$
$\alpha\odot(\beta\odot u)=\alpha\odot(\beta\odot(x_1,x_2))$
$=\alpha\odot(\beta x_1,\beta x_2)$
$=(\alpha\beta x_1,\alpha\beta x_2)$
$=\alpha\beta\odot(x_1,x_2)=(\alpha\beta)\odot u$

(2) $1\odot u= u$ for every $u∈V=\mathbb{R}^2$.
$u=(x_1,x_2)∈\mathbb{R}^2$

$1\odot u=1\odot(x_1,x_2)$
$=(1\cdot x_1,1\cdot x_2)$
$=(x_1,x_2)=u$

#### Distributive laws:
For any $\alpha,\beta ∈\mathbb{R}$ and $u,v∈V=\mathbb{R}^2$
(a) $\alpha\odot(u\oplus v)=(\alpha\odot u)\oplus(\alpha\odot v)$(?)
(b) $(\alpha+\beta)\odot u=(\alpha\odot u)\oplus(\beta\odot u)$(?)

(a) $u=(x_1,x_2)∈\mathbb{R}^2$
$v=(y_1,y_2)∈\mathbb{R}^2$
$\alpha\odot(u\oplus v)=\alpha\odot((x_1,x_2)\oplus(y_1,y_2))$
$=(\alpha(x_1+y_1),\alpha(x_2+y_2))$
$=(\alpha x_1+\alpha y_1,\alpha x_2+\alpha y_2)$ 

(3) let $\mathbb{R}^n=\{(a_1,a_2,\dots,a_n)|a_i∈\mathbb{R}\space 1≤i≤n\}$ be the set of n-tuples of real numbers. For $u=(a_1,\dots,a_n)$, $v=(b_1,\dots,b_n)∈\mathbb{R}^n$.
And $\alpha∈\mathbb{R}$, we define 
$u\oplus v=(a_1+b_1,\dots,a_n+b_n)$
$\alpha\odot u=(\alpha a_1,\dots,\alpha a_n)$
(called component wise)

Then $\mathbb{R}^2$ is a real vector space with addition and scaler multiplication defined as above.

(4) let $V=\mathbb{R}^+$ (the set of positive real numbers)
Is $\mathbb{R}^+$ a real vector space?
Is there any $0∈\mathbb{R}^+$ s.t for every $u∈\mathbb{R}^+$ $u\oplus 0=u$(?)
$0\neq\mathbb{R}^+$. $\mathbb{R}^+$ is not a real vector space with respect to usual addition.

Now define a new vector addition and scalar multiplication as $v_1\oplus v_2=v_1\cdot v_2$, $\alpha\odot v=V^{\alpha}$ for all $v_1, v_2,v∈\mathbb{R}^+$ and $\alpha∈\mathbb{R}$.
=>$\mathbb{R}^+$ is a real vector space with these operations.

$\mathbb{R}^+$ is not a real vector space with respect to operations as follows: $\oplus:=+\space\odot:=\cdot$
$\mathbb{R}^+$ is a real vector space with respect to the operations: $u\oplus v=u\cdot v$ $\alpha\odot u=u^{\alpha}$

NOTE: From now on, we will use $u+v$ in place of $u\oplus v$ and $\alpha\cdot u$ in place of $\alpha\odot u$ where $\alpha∈\mathbb{R}$ $u,v∈V$.
