Defn: (Vector Subspaces)
let $S$ be a non-empty subset of $V$. $S(\mathbb{R})$ is said to be a subspace of $V(\mathbb{R})$ $\alpha u+\beta v∈ S$ for every $\alpha,\beta∈\mathbb{R}$ and where the vector addition and $u,v∈S$. Scaler multiplication are same as that of $V(\mathbb{R})$.

Ex: let $V(F)$ be a vector space. Then
(a) $S=\{0\}$, the set consisting of the zero vector 0.
(b) $S=V$ are vector subspaces of $V$.
These are called trivial subspaces.