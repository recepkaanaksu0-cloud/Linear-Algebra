### Submatrix of a Matrix
**Definition:** A matrix obtained by deleting some rows and/or columns of a matrix is said to be a **submatrix** of the given matrix.

---

### Trace of a Matrix
**Definition:** For a square matrix $A$ of order $n$, the **trace** of $A$, denoted by $\text{tr}(A)$, is defined as:

$$
\text{tr}(A) = a_{11} + a_{22} + \dots + a_{nn}
$$

**Theorem:** Let $A$, $B$ be square matrices of order $n$. Then:
- (a) $\text{tr}(A + B) = \text{tr}(A) + \text{tr}(B)$  
- (b) $\text{tr}(AB) = \text{tr}(BA)$

**Example:**
$$
\begin{bmatrix}
1 & 2 & 3 \\
4 & 5 & 6 \\
7 & 8 & 9
\end{bmatrix}
$$

---

### Matrices Over Complex Numbers

Let $A = [a_{ij}]$ be an $m \times n$ matrix over $\mathbb{C}$.

1. The **conjugate** of $A$, denoted by $\bar{A}$, is the matrix $B = [\bar{a}_{ij}]$  
2. The **conjugate transpose** of $A$, denoted by $A^*$, is the matrix $B = [\bar{a}_{ji}]$

**Example:**
$$
A = \begin{bmatrix}
2 + 3i & 1 \\
0 & 5 - 7i
\end{bmatrix}, \quad
A^t = \begin{bmatrix}
2 + 3i & 0 \\
1 & 5 - 7i
\end{bmatrix}, \quad
A^* = \begin{bmatrix}
2 - 3i & 0 \\
1 & 5 + 7i
\end{bmatrix}
$$

**Matrix Types:**
- Hermitian: $A^* = A$
- Skew-Hermitian: $A^* = -A$
- Unitary: $AA^* = I = A^*A$
- Normal: $AA^* = A^*A$

**Note:**
- $A^* = A$ over $\mathbb{C}$ implies Hermitian  
- $A^t = A$ over $\mathbb{R}$ implies Symmetric

---

### Linear System of Equations

**Definition:** A linear system of $m$ equations in $n$ unknowns $x_1, x_2, \dots, x_n$ is:

$$
\begin{aligned}
a_{11}x_1 + a_{12}x_2 + \dots + a_{1n}x_n &= b_1 \\
a_{21}x_1 + a_{22}x_2 + \dots + a_{2n}x_n &= b_2 \\
\vdots \\
a_{m1}x_1 + a_{m2}x_2 + \dots + a_{mn}x_n &= b_m
\end{aligned}
$$

The system is **homogeneous** if $b_1 = b_2 = \dots = b_m = 0$, otherwise **non-homogeneous**.

Matrix form:
$$
AX = B
$$

Where:
$$
A = \begin{bmatrix}
a_{11} & a_{12} & \dots & a_{1n} \\
\vdots & \vdots & \ddots & \vdots \\
a_{m1} & a_{m2} & \dots & a_{mn}
\end{bmatrix}, \quad
X = \begin{bmatrix}
x_1 \\
x_2 \\
\vdots \\
x_n
\end{bmatrix}, \quad
B = \begin{bmatrix}
b_1 \\
b_2 \\
\vdots \\
b_m
\end{bmatrix}
$$

Augmented matrix:
$$
[A \,|\, B] = \begin{bmatrix}
a_{11} & \dots & a_{1n} & b_1 \\
\vdots & \ddots & \vdots & \vdots \\
a_{m1} & \dots & a_{mn} & b_m
\end{bmatrix}
$$

Associated homogeneous system:
$$
AX = 0
$$

---

### Solution of a Linear System

A solution is a column vector $Y = [y_1, y_2, \dots, y_n]^t$ such that:
$$
AY = B
$$

**Trivial Solution:**
$$
X = \begin{bmatrix}
0 \\
0 \\
\vdots \\
0
\end{bmatrix}
$$

**Non-trivial Solution:** Any non-zero vector $X$ satisfying $AX = 0$

**Example:**
$$
\begin{aligned}
x + 7y + 3z &= 11 \\
x + y + z &= 3 \\
4x + 10y - z &= 13
\end{aligned}
\quad \Rightarrow \quad x = y = z = 1
$$

---

### Row Operations and Equivalent Systems

**Elementary Operations:**
1. Interchange two equations  
2. Multiply an equation by a non-zero constant  
3. Replace an equation by itself plus a constant multiple of another equation

**Definition:** Two systems are **equivalent** if one can be obtained from the other by a finite number of elementary operations.

**Lemma:** If $Cx = d$ is obtained from $Ax = b$ by a single elementary operation, then both systems have the same solution set.

**Theorem:** Equivalent systems have the same set of solutions.

**Note:** Instead of working with equations directly, we use the **augmented matrix** $[A \,|\, B]$.

---