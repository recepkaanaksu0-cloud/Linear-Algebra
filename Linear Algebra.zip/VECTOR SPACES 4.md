Theorem: let $\{v_1,v_2,\dots,v_p\}$ be a linearly independent subset of a vector space $V$. Suppose therer exists $\{v_1,v_2,\dots,v_p,v_{p+1}\}$ is alinearly dependent then $v_{p+1}$ is a linear combination of $v_1,v_2,\dots,v_p$.

Corollary: let $\{u_1,\dots,u_n\}$ be a linearly dependent subset of a vector space $V$. Then there exists a smallest $k$, $2≤k≤n$ such that $L(u_1,u_2,\dots,u_k)=L(u_1,u_2,\dots,u_{k-1})$.

Corollary: let $\{v_1,v_2,\dots,v_p\}$ be a linearly independent subset of a vector space $V$ such that $V\notin L(v_1,\dots,v_p)$. Then the set $\{v_1,v_2,\dots,v_p,v\}$ also linearly independent subset of $V$.