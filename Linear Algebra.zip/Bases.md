Defn: (Basis of a Vector Space)
A non-empty subset of $B$ of a vector space $V$ is called a basis of $V$ if
(1) $B$ is linearly independent set and
(2) $L(B)=V$, i.e, every vector in $V$ can be expressed as a linear combinition of the elements of $B$.

Note: A vector in B is called a basis vector.

Remark: let $\{v_1,v_2\dots,v_p\}$ be a basis of a vector space $V$. Then any $v\in V$ is a unique linear combination of the basis vectors $v_1,v_2,\dots,v_p$. Observe that if there exists $v\in V$ s.t $v=\alpha_1v_1+\alpha_2v_2+\dots+\alpha_pv_p$ and $v=\beta_1v_1+\beta_2v_2+\dots+\beta_pv_p$. Then $0=v+(-v)=(\alpha_1-\beta_1)v_1+\dots+(\alpha_p\beta_p)v_p$. The set $\{v_1,\dots,v_p\}$ is linearly independent and hence the second scalers $\alpha_i-\beta_i$ for $1≤i≤p$ must be zero. Thus$1≤i≤p$ $\alpha_i=\beta_i$ and we have uniqueness.

NOTE: The linear span of an empty set is $\{0\}$. Hence, the empty set is a basis of the vector space $\{0\}$.

Ex:
(1) Check that if $V= \{{(x,y,0)|\space x,y\in\mathbb{R}}\}$ $≤\mathbb{R}^3$, then $B_1=$ $\{(1,0,0),(1,1,0)\}$ and $B_2=\{(1,0,0),(0,1,0)\}$ are bases of $V$.
(a) $B_1\neq\emptyset$

(b) If $a(1,0,0)+b(1,1,0)=(0,0,0)$ 
$(a+b,b,0)=(0,0,0)$
$a+b=0$
$b=0$
$a=0$
=> $B_1$ is linearly independent subset.

(c) $L(B_1)=V$
$L(B_1)\subseteq v$
$L(B_1)\supseteq?$
let $(x,y,0)\in V$.
$(x,y,0)=a(1,0,0)+b(1,1,0)=>V\subseteq L(B_1)$
$(x,y,0)=(a+b,b,0)=>L(B_1)=V$
From (a),(b),(c), $B_1$ is a basis of $V$.

(2)
(a) $B_2\neq\emptyset$

(b) $a(1,0,0)+b(0,1,0)=(0,0,0)$
$(a,b,0)=(0,0,0)$
$a=b=0$
=> $B_2$ is a linearly independent subset.

(c) $L(B_2)=V$
For every vector $v=(x,y,0)\in V$, 
$(x,y,0)=a(1,0,0)+b(0,1,0)$
$(x,y,0)=(a,b,0)$
$a=x$
$b=y$
$(x,y,0)=x(1,0,0)+y(0,1,0)$.
=> $L(B_2)=V$
=> $B_2$ is a basis of $V$.

Ex: let $V=\{(x,y,z)|\space x+y-z=0, x,y,z\in\mathbb{R}\}$ be a vector subspace of $\mathbb{R}^3$.
let $S= \{(1,1,2),(2,1,3),(1,2,3)\} \subset V$.

(a) $S\neq\emptyset$.

(b) Is $S$ a linearly independent subset?
$a(1,1,2)+b(2,1,3)+c(1,2,3)=(0,0,0)$
$(a+2b+c,a+b+2c,2a+3b+3c)=(0,0,0)$
$a+2b+c=0$
$a+b+2c=0$
$2a+3b+3c=0$
$a=-3c$
$b=c$
$c\in\mathbb{R}$
$3(1,1,2)-1(2,1,3)=(1,2,3)$
$c=-1,a=3,b=-1$
$3(1,1,2)-(2,1,3)-(1,2,3)=(0,0,0)$
=> $S$ cannot be a basis of $V$ since it is linearly dependent subset.

2nd Solution:
$(3,2,5)\in V$
$(3,2,5)=(1,1,2)+(2,1,3)$
$(3,2,5)=4(1,1,2)-(1,2,3)$
So linear combination of the vectors in $S$ is not unique.
=> $S$ cannot be a basis of $V$.

If $S$ is a basis of $V$, then every vector of $V$ ,is written as a linear combination of the elements of $S$, uniquely.

Note: A basis of $V=\{(x,y,z)|\space x+y-z=0\}$ can be obtained by the following method:
The condition $x+y-z=0$ is equivalent to $z=x+y$. So 
$(x,y,z)=(x,y,x+y)=(x,0,x)+(0,y,y)$
$(x,y,z)=x(1,0,1)+y(0,1,1)$
=> $\{(1,0,1),(0,1,1)\}=dim(V)=2$
forms of a basis of $V$.

Defn: (Finite Dimensional Vector Space)
A vector space $V$ is said to be finite dimensional if a basis of $V$ containing finite number of elements. Otherwise, a vector space $V$ is called infinite dimensional.

Defn: The dimension of a finite dimensional vector space $V$ is the number of the vectors in a basis of $V$, denoted by $dim(V)$.

Ex: Consider the vector space $P(\mathbb{R})$ of all polynomials with real coefficients.
A basis of this vector space is the set $\{1,x,x^2,\dots,x^n,\dots\}$. $P(\mathbb{R})$ is an ifinite dimensional vector space.