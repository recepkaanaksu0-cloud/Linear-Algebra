Defn: (Row Reduced Echelon Form of a Matrix)
A Matrix $C$ is said to be in the row reduced echelon form if:
(1) $C$ is already in the row reduced form.
(2) The rows consisting of all zeros comes below all non-zero rows.
(3) The leading terms appear from left to right in successive rows.

Ex: Consider the matrix

$A=\begin{bmatrix}0 & 1 & 0 & 2 \\0 & 0 & 0 & 0 \\0 & 0 & 1 & 1 \\\end{bmatrix}$
is a row reduced form.
is not a row reduced echelon form.

$B=\begin{bmatrix}0 & 1 & 0 & 2 \\0 & 0 & 1 & 1 \\0 & 0 & 0 & 0 \\\end{bmatrix}$
is a row reduced matrix.
is a row reduced echelon matrix.

Ex:$\begin{bmatrix}1 & 0 & 0 & 2 \\0 & 0 & 1 & 1 \\0 & 0 & 0 & 0 \\\end{bmatrix}$
is a row reduced matrix.
is a row reduced echelon matrix.

Ex: $A=\begin{bmatrix}0 & 0 & 1 & 1 \\1 & 0 & 0 & 2 \\0 & 0 & 0 & 0 \\\end{bmatrix}$
is a row reduced matrix.
is not a row reduced matrix.